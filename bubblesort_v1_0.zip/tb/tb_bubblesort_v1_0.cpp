/*-------------------------------------------------------
  testbench for bubble sorter
-------------------------------------------------------*/


#include "../src/sorter_defs_v1_0.h"

//#define NDEBUG
#include <assert.h>


int main() {

	// test variables
    ADDR_t tb_startAddr = 128;
    LSIZE_t tb_listSize = 8;
    unsigned int tb_arraysize = 0;


	DATA_t  temp = 0;
	DATA_t tb_array[memSize];
	tb_arraysize = tb_startAddr + tb_listSize;



	// ALL SAME TEST
	cout << "---------------------------------" << endl;
	for (int i=0; i < memSize; i++) {
		tb_array[i] = 7;
	}
   	bubblesort(tb_startAddr, tb_listSize, tb_array);
   	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED all same case" << endl;
	cout << "---------------------------------" << endl;


    // MAX VALUE FIRST
	for (int i=0; i < memSize; i++) {
		tb_array[i] = 7;
	}
	tb_array[tb_startAddr] = 10;
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED max value first case" << endl;
	cout << "---------------------------------" << endl;


    // MAX VALUE LAST
	for (int i=0; i < memSize; i++) {
		tb_array[i] = 7;
	}
	tb_array[tb_arraysize-1] = 10;
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED max value last case" << endl;
	cout << "---------------------------------" << endl;


    // MIN VALUE FIRST
	for (int i=0; i < memSize; i++) {
		tb_array[i] = 12;
	}
	tb_array[tb_startAddr] = 4;
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED min value first case" << endl;
	cout << "---------------------------------" << endl;


    // MIN VALUE LAST
	for (int i=0; i < memSize; i++) {
		tb_array[i] = 13;
	}
	tb_array[tb_arraysize-1] = 10;
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED min value last case" << endl;
	cout << "---------------------------------" << endl;


	// INCREMENTING NUMBERS TEST
	for (int i=0; i < memSize; i++) {
		tb_array[i] = i;
	}
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED incrementing numbers case" << endl;
	cout << "---------------------------------" << endl;


	// DECREMENTING NUMBERS TEST
	temp = memSize - 1;
	for (int i=0; i < memSize; i++) {
		tb_array[i] = temp;
		temp--;
	}
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED decrementing numbers case" << endl;
	cout << "---------------------------------" << endl;



    // RANDOM NUMBERS TEST
	srand((unsigned)time(NULL));

	for (int i=tb_startAddr; i < memSize; i++) {
		DATA_t tb_random = rand();
		tb_array[i] = tb_random;;
	}
	bubblesort(tb_startAddr, tb_listSize, tb_array);
	chkResults(tb_array, tb_startAddr, tb_listSize);
	cout << "PASSED random numbers case" << endl;
	cout << "---------------------------------" << endl;


  return 0;

}



void chkResults(DATA_t testArray[memSize], ADDR_t startAddr, LSIZE_t listSize) {

	DATA_t  temp = 0;

	for (int i = startAddr; i < listSize+startAddr; i++) {
		assert (testArray[i] >= temp);
		temp = testArray[i];
		cout << dec << testArray[i] << endl;
	}

}
