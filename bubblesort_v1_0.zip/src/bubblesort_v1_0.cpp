/*----------------------------------------------------------------------------------
  Bubble sorter
  
  Ver 1.0
  
  Will exit when no more swaps are done which indicates that list is sorted.
  Optimized to skip already sorted elements.

  The list will be sorted with the smallest value at the beginning of list (array
  index 0). The order can be changed by changing the comparison between successive elements
  - see comments in the code.

  Arguments:

  startAddr            : start addr of list to be sorted
  listSize             : size of list to be sorted
  sortList[memSize]    : creates an interface to list to be sorted.
----------------------------------------------------------------------------------*/   


#include "sorter_defs_v1_0.h"



void bubblesort(ADDR_t startAddr, LSIZE_t listSize, DATA_t sortList[memSize])
{
	/*----------------------------------------------------------
	 * Pragmas for startAddr, listSize and the control ports
	 ----------------------------------------------------------*/
	// these pragmas bundle the input arguments into an AXI lite
	// interface for software control
	// #pragma HLS INTERFACE s_axilite port=startAddr   bundle=CTL
	// #pragma HLS INTERFACE s_axilite port=listSize    bundle=CTL
	// #pragma HLS INTERFACE s_axilite port=return      bundle=CTL



	/*----------------------------------------------------------
	 * Pragmas for the memory interface
	 ----------------------------------------------------------*/
	// this pragma will implement the memory interface as AXI-MM
    // #pragma HLS INTERFACE m_axi port=sortList offset=off

	// these pragmas together will implement the interface to the
	// memory as a single port BRAM
     #pragma HLS INTERFACE bram port=sortList
     #pragma HLS RESOURCE variable=sortList core=RAM_1P


	// these pragmas together will implement the interface to the
	// memory as a dual port BRAM
    // #pragma HLS INTERFACE bram port=sortList
    // #pragma HLS RESOURCE variable=sortList core=RAM_2P




	bool swapDone = true;
	unsigned int bound = startAddr + listSize - 1;
	unsigned int new_bound = startAddr;


  
	/* This loop is executed until list is ordered */
	  loop0: while (swapDone) {

		 swapDone = false;
        
        /* This loop does one scan of the list, starting from 1st
           element and ending at position of last swap of previous scan */
        loop1: for (int j = startAddr; j < bound; j++)  {

        	DATA_t temp;

        	// sort from smallest to largest
        	if (sortList[j] > sortList[j + 1])  {

        	// sort from largest to smallest
            //if (sortList[j] < sortList[j + 1])  {

        		temp = sortList[j];
        		sortList[j] = sortList[j + 1];
                sortList[j + 1] = temp;
                swapDone = true;
                new_bound = j;
            }
        }
        bound = new_bound;

    }

}
 /*--------------------------------------------------------------------------------
  End of File: bubblesort.cpp
----------------------------------------------------------------------------------*/   







